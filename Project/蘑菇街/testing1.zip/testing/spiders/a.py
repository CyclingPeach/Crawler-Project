# -*- coding: utf-8 -*-
import re
import scrapy
import requests
from lxml import etree
from urllib import request
from unicodedata import category
from testing.items import ShopItem


website = 'a'

class ASpider(scrapy.Spider):
    name = website
    # allowed_domains = ['a.com']
    # start_urls = ['http://a.com/']

    @classmethod
    def update_settings(cls, settings):
        custom_debug_settings = getattr(cls, 'custom_debug_settings' if getattr(cls, 'is_debug', False) else 'custom_settings', None)
        settings.setdict(custom_debug_settings or {}, priority='spider')

    def __init__(self, **kwargs):
        super(ASpider, self).__init__(**kwargs)
        self.counts = 0
        setattr(self, 'author', "")

    is_debug = True
    custom_debug_settings = {
        'MONGODB_COLLECTION': website,
        'CONCURRENT_REQUESTS': 4,
        'DOWNLOAD_DELAY': 1,
        'LOG_LEVEL': 'DEBUG',
        'COOKIES_ENABLED': False,
        'DOWNLOADER_MIDDLEWARES': {
            'testing.middlewares.TestingUserAgentMiddleware': 100,
        },
        'ITEM_PIPELINES': {
            'testing.pipelines.TestingPipeline': 300,
        },
    }


    def start_requests(self):
        """
        网站主页：从这里开始进入
        """
        url = "https://www.nastygal.com/gb/"
        yield scrapy.Request(
            url=url,
        )


    def parse(self, response):
        """
        类目页：获取所有类目列表页，传入到 parse_list
        传  入： https://www.nastygal.com/gb/ 首页的 HTML
        传  出： category = [{
            'category_name' : category_name,
            'category_href' : category_href
        }, ]
        """
        result = etree.HTML(response)
        main_menu = result.xpath('//ul[@id="main-menu"]/li')

        category = []
        for li in main_menu:
            try:
                category_name = li.xpath('./a/text()')[0].strip()
                category_href = li.xpath('./a/@href')[0]
                category.append({
                    'category_name':category_name, 
                    'category_href':category_href
                })
            except:
                continue

        category[0]['category_href'] = 'https://www.nastygal.com' + category[0]['category_href']
        category[-2]['category_href'] = 'https://www.nastygal.com' + category[-2]['category_href']

        return category[:-1]

    def parse_list(self, response):
        """
        列表页：获取所有商品详情页的链接，传入到 parse_detail
        注  意： 翻页逻辑
        传  入： 一个类别商品链接 的字典 {
            'category_name' : category_name,
            'category_href' : category_href
        } 
        传  出： 所有商品详情页的链接 列表 current_category_product = [{
            'product_name':product_name,
            'product_href':product_href
        }, ]
        """
        category_href = response['category_href']

        category_html = etree.HTML(requests.get(category_href).text)     # 该类别页面的 HTML
        product_total = int(category_html.xpath('//div[@class="b-load_progress"]/span/span[2]/text()')[0].replace(',', ''))     # 该 类别的总商品数
        page_total = product_total//60      # 总页数

        current_category_product = []       # “该类别中所有页” 的商品列表
        for page in range(page_total):      # 遍历该类别的所有页
            # start 从 60 开始。即 start=60 代表第一页
            url = f'https://www.nastygal.com/gb/womens?start={(page+1)*60}&sz=60'
            # print(url)
            product_html = etree.HTML(requests.get(url).text)

            sections = product_html.xpath('//div[@id="product-grid"]/div[2]/section')
            current_page_product = []   # “该页” 中所有商品 的列表
            for section in sections:    # 遍历该类别的所有商品
                product_name = section.xpath('./div[2]/div[1]/h3/a/text()')[0].strip()  # 商品名称
                if 'https://www.nastygal.com' in section.xpath('./div[2]/div[1]/h3/a/@href')[0]:
                    product_href = section.xpath('./div[2]/div[1]/h3/a/@href')[0]
                else:
                    product_href = 'https://www.nastygal.com' + section.xpath('./div[2]/div[1]/h3/a/@href')[0]
                current_page_product.append({
                    'product_name':product_name, 
                    'product_href':product_href
                })
            current_category_product += current_page_product    # “该类别中所有页” 的商品列表
        
        return current_category_product
    
    def parse_detail(self, response):
        item = ShopItem()
        print('进入到详情页')
        product_href = response['product_href']
        print(product_href)
        product_html = etree.HTML(requests.get(product_href, verify=False).text)
        item['name']           = product_html.xpath('//div[@class="b-product_details-breadcrumbs"]/nav/ol/li/a/span/text()')[-1]
        item['detail_cat']     = product_html.xpath('//div[@class="b-product_details-breadcrumbs"]/nav/ol/li/a/span/text()')[-2]
        item['original_price'] = product_html.xpath('//div[@class="b-product_details-price"]/div[1]/span[2]/text()')[0].strip()
        item['current_price']  = product_html.xpath('//div[@class="b-product_details-price"]/div[1]/span[4]/text()')[0].strip()
        item['description']    = product_html.xpath('//div[@class="b-product_details-content"]//text()')    # 待处理
        description = etree.tostring(product_html.xpath('//div[@class="b-product_details-content"]')[0]).decode()
        item['description']    = re.sub('<p.*?>|</p>|<br>|<br/>|<li>|</li>|<span.*?>|</span>|<div.*?>|</div>|<ul.*?>|</ul>|\n', '', description)
        item['image']          = 'https:' + product_html.xpath('//div[@class="b-product_gallery-track"]/div/picture/img/@src')[0]
        item['url']            = product_html.xpath('//div[@class="b-product_details-breadcrumbs"]/nav/ol/li/a/@href')[-1]

        return item